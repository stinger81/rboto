# /bin/python3
# ##########################################################################
#
#   Copyright (C) 2024 Michael Dompke (https://github.com/stinger81)
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
#   Michael Dompke (https://github.com/stinger81)
#   michael@dompke.dev
#
# ##########################################################################

import time
import math
import serial
import threading

# Constant
JOY_SIZE = 1000 # what should one side be expanded to

class dummyInterface:
    def __init__(self):
        pass
    def send_data(self,**kwargs):
        print(kwargs)
    def send_stop(self):
        print("stop")
    def get_telemetry(self):
        return "TEL UNAVAILABLE THROUGH DUMMY INTERFACE"
class SerialInterface:
    """
    WARNING
    WARNING
    WARNING

    MODIFY THIS FILE AT YOUR OWN RISK
    CHANGING THIS FILE WILL DIRECTLY AFFECT HOW THE DATA SENT TO THE ARDUINO
    MAKE SURE THAT YOU UPGRADE THE ARDUINO CODE ACCORDINGLY
    """


    def __init__(self, port, baudrate):
        self.port = port
        self.baudrate = baudrate
        self.ser = serial.Serial(port=port,
                                 baudrate=baudrate,
                                 timeout=0.1)

        self.telemetry_buf = []
        self.message_buf = []

    def __del__(self):
        try:
            self.ser.close()
        except:
            pass

    def send_data(self, in_left_track_rate:float, in_right_track_rate:float):
        """
        Send the left and right track rates to the arduino
        :param in_right_track_rate: -1 to 1
        :param in_left_track_rate: -1 to 1
        :return: None
        """
        left_track_rate = self._pack_joy_data(in_left_track_rate)
        right_track_rate = self._pack_joy_data(in_right_track_rate)

        # compile the data

        data = "D,"
        data += left_track_rate
        data += ","
        data += right_track_rate
        data += "\n"
        self._write(data.encode("utf-8"))

    def send_stop(self):
        """
        Send the stop command to the arduino
        :return: None
        """
        data = "S\n"
        self._write(data.encode("utf-8"))

    def get_telemetry(self) -> str:
        data_out = "R\n"
        self._write(data_out.encode("utf-8"))
        # get data back
        return self._read().decode()


    def process_incoming(self, limit: int = -1):
        """
        Process the incoming data from the arduino
        :return: None
        """
        # THIS IS VERY VERY VERY BROKEN
        errorCount = 0
        errorMax = 2
        while True:
            data = self._read()
            print(data)
            if data == b"":
                return
            elif data[0] not in [b"T", b"M"] or not data.endswith(b"\r\n"):
                errorCount += 1
                # clear next message since it is also messed up
                self._read()
                if errorCount > errorMax:
                    return
            data = data.decode().strip("\r\n")
            if data[0] == "T":
                self.telemetry_buf.append(data.split(","))
                print(self.telemetry_buf[-1])
            elif data[0] == "M":
                self.message_buf.append(data.split(","))
                print(self.message_buf[-1])

    def _pack_joy_data(self, value):
        if value > 1:
            value = 1
        elif value < -1:
            value = -1
        # normalize between 0 and 2
        value += 1
        # convert to value between 0 and 2000
        value *= JOY_SIZE
        return str(int(value)).zfill(4)



    def _write(self, data):
        self.ser.write(data)

    def disp_incoming_thread(self):
        while True:
            print(self._read().decode().strip("\r\n"))
    def _read(self):
        return self.ser.read_until(b'\n')

    def close(self):
        self.ser.close()

if __name__ == "__main__":
    ser = SerialInterface("COM8", 9600)
    # ser.send_data(-1, 1)
    # # time.sleep(1)
    # while True:
    #     print(ser._read())

    # data sweep
    my_min = -1
    my_max = 1
    my_step = 0.1
    my_range = int((my_max - my_min)/my_step) + 1

    for i in range(my_range):
        print("SENT")
        my_val = my_min + (my_step *i)
        ser.send_data(my_val,my_val)
        time.sleep(0.1)
        print(ser._read().decode().strip("\r\n"))
    time.sleep(1)
    # ser.process_incoming()


    ser.close()
    print("done")